﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PUPiMed
{
    public partial class FormAddDistribItem : MetroForm
    {
        public FormAddDistribItem()
        {
            InitializeComponent();
        }

        private void FormAddDistribItem_Load(object sender, EventArgs e)
        {

        }

        private void materialCheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox14_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void materialCheckBox15_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void itemcode_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }


        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void itemtype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroLabel8_Click(object sender, EventArgs e)
        {

        }

        private void balance_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel9_Click(object sender, EventArgs e)
        {

        }

        private void total_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel7_Click(object sender, EventArgs e)
        {

        }

        private void UOM_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroLabel6_Click(object sender, EventArgs e)
        {

        }

        private void qty_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel5_Click(object sender, EventArgs e)
        {

        }

        private void available_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
