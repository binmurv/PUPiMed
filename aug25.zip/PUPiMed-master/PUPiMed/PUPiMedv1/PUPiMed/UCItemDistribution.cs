﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace PUPiMed
{
    public partial class UCItemDistribution : UserControl
    {
        public UCItemDistribution()
        {
            InitializeComponent();
            updateTable();
        }

        private void gridDistribution_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void mpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }
        public void updateTable()
        {
            string strQuery =
                "select "+
                    "e.strBranDesc AS 'Branch', " +
                    "CASE WHEN a.intItemType = 1 THEN 'Medicine' WHEN a.intItemType = 2 THEN 'Supply' ELSE 'Equipment' END AS 'Type', " +
                    "a.strItemCode AS 'Item Code',  " +
                    "a.strItemName AS 'Item Name', " +
                    "b.intBDIDQty AS 'Quantity', " +
                    "CASE WHEN b.intBDIDUom = 0 THEN 'Box' ELSE 'Piece' END AS 'Unit of Measurement', " +
                    "c.datBraDDate AS 'Date' " +
                 "from tblItem a INNER JOIN tblBranItemDetail b ON a.strItemCode = b.strBDIDItemCode " +
                                "INNER JOIN tblBranchDistribution c ON b.strBDIDBradCode = c.strBraDCode " +
                                "INNER JOIN tblBranCampusDetail d ON c.strBraDCode = d.strBRaDCode " +
                                "INNER JOIN tblBranch e ON d.strBraDBranCode = e.strBranCode " +
                 "where a.boolItemDeleted = 0; ";
            try
            {
                Program.conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(strQuery, Program.conn))
                {
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        try
                        {
                            sda.Fill(dt);
                            grid.DataSource = dt;

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message.ToString());
                        }
                        finally
                        {
                            dt.Dispose();
                        }
                    }
                }
            }catch(Exception exx)
            {
                MessageBox.Show(exx.Message.ToString());
            }
            finally
            {
                Program.conn.Close();
            }
        }
        private void AddDistibItem_Click(object sender, EventArgs e)
        {
            new FormAddDistribItem(this).ShowDialog();
        }
    }
}
