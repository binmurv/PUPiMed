﻿using MetroFramework;
using MetroFramework.Controls;
using MetroFramework.Forms;
using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace PUPiMed
{
    public partial class FormAddDistribItem : MetroForm
    {

        UCItemDistribution parent;
        ArrayList alistCode;
        List<string> campus = new List<string>();
        List<string> campuscode = new List<string>();
        ComboBoxFn mn = new ComboBoxFn();
        string strType, strCode, strName, strQty, strUOM, strDCode, strDate;
        int intBalance, intTotal, intAvailable, intQty;
        
        public FormAddDistribItem(UCItemDistribution parent)
        {
            InitializeComponent();
            this.parent = parent;
            cbType.SelectedIndex = 0;
            cbUOM.SelectedIndex = 0;
            cbType.Focus();
            loadBranches();
        }

        private void getBalance(string code)
        {
            intAvailable =  int.Parse(Program.getPrevCode("SELECT fnGetBalance('"+code+"');"));
            txtAvailable.Text = intAvailable.ToString();
        }

        private void getIntValues()
        {
            strQty = txtQty.Text;
            if (!Int32.TryParse(strQty, out intQty))
            {
                txtQty.Text = "0";
            }
            getSelectedCampus();
            int count = campus.Count;
            intTotal = intQty * count;
            intBalance= intAvailable - intTotal;
            txtBalance.Text = intBalance.ToString();
            txtTotal.Text = intTotal.ToString();
            
        }

        private void getSelectedCampus()
        {
            campus.Clear();
            foreach (int index in this.cbBranch.CheckedIndices)
            {
               campus.Add(campuscode[index]);
            }
        }

        private void clearItems()
        {
            txtQty.Text = "0";
            txtBalance.Text = "0";
            txtAvailable.Text = "0";
            txtTotal.Text = "0";
            foreach (int index in this.cbBranch.CheckedIndices)
            {
                cbBranch.SetItemChecked(index, false);
            }
            foreach (var cb in this.Controls.OfType<ComboBox>())
            {
                cb.SelectedIndex = 0;
            }
            
            dtDate.Value = DateTime.Today;
            
        }

        private void FormAddDistribItem_Load(object sender, EventArgs e)
        {

        }

        private void UOM_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (everythingIsOkay())
            {
                if (intBalance >= 0)
                {
                    if (saveHeader())
                        if (saveCampusDetail())
                            if (saveItemDetail())
                            {
                                MetroMessageBox.Show(this, "Success.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Question);
                                clearItems();
                            }
                }
                else
                    MetroMessageBox.Show(this, "Insufficient stock.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MetroMessageBox.Show(this, "Please fill in the required fields before adding.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void panel_Click(object sender, EventArgs e)
        {
            getIntValues();
        }

        private void materialCheckBox5_CheckStateChanged(object sender, EventArgs e)
        {
            getIntValues();
        }

        private void metroLabel8_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel6_Click(object sender, EventArgs e)
        {

        }

        private void txtTotal_Click(object sender, EventArgs e)
        {

        }

        private void dtDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void metroLabel5_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel7_Click(object sender, EventArgs e)
        {

        }

        private void txtBalance_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel2_Click_1(object sender, EventArgs e)
        {

        }

        private void txtQty_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click_1(object sender, EventArgs e)
        {

        }

        private void metroLabel1_Click_1(object sender, EventArgs e)
        {

        }

        private void txtAvailable_Click(object sender, EventArgs e)
        {

        }

        private void txtCode_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel11_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel8_Click_1(object sender, EventArgs e)
        {

        }

        private void lblCode_Click(object sender, EventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.parent.updateTable();
            this.Dispose();
        }

        private void pbAddItem_Click(object sender, EventArgs e)
        {
            string bcode = Program.getNextCode(Program.getPrevCode("SELECT * FROM tblBranch ORDER BY strBranCode DESC LIMIT 1;"));
            if (!string.IsNullOrWhiteSpace(txtBranch.Text))
            {
                if (!Program.ExecuteQuery("INSERT INTO tblBranch VALUES('"+bcode+"', '"+txtBranch.Text+"')")) { }
            }
            loadBranches();
        }

        private void cbBranch_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            getIntValues();
        }

        private void cbBranch_MouseClick(object sender, MouseEventArgs e)
        {
            getIntValues();
        }

        private void txtQty_TextChanged(object sender, EventArgs e)
        {
            if(!String.IsNullOrWhiteSpace(txtQty.Text)|| !String.IsNullOrEmpty(txtQty.Text))
                getIntValues();
        }

        private void cbBranch_Enter(object sender, EventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(txtQty.Text) || !String.IsNullOrEmpty(txtQty.Text))
                getIntValues();
        }

        private void cbBranch_MouseEnter(object sender, EventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(txtQty.Text) || !String.IsNullOrEmpty(txtQty.Text))
                getIntValues();
        }

        private void cbBranch_MouseClick_1(object sender, MouseEventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(txtQty.Text) || !String.IsNullOrEmpty(txtQty.Text))
                getIntValues();
        }

        private void getCode()
        {
            //check if theres an existing code
            string prevCode = Program.getPrevCode("SELECT * from tblBranchDistribution ORDER by strBradCode DESC LIMIT 1;");
            if (string.IsNullOrEmpty(prevCode))
            {
                strDCode = "dist-000";

            }
            else
            {
                strDCode = Program.getNextCode(prevCode);
            }
        }
        private bool everythingIsOkay()
        {
            getCode(); //code for dist
            strType = cbType.SelectedItem.ToString();
            strCode = txtCode.Text;
            strName = cbName.SelectedItem.ToString();
            strUOM = cbUOM.SelectedIndex.ToString();
            strQty = txtQty.Text;
            if (!Int32.TryParse(strQty, out intQty))
            {
                MetroMessageBox.Show(this, "Please enter a numeric value for 'Quantity'", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            strDate = dtDate.Value.ToString("yyyy-MM-dd");

            if (string.IsNullOrWhiteSpace(strDCode) || string.IsNullOrWhiteSpace(strDate) || string.IsNullOrWhiteSpace(strUOM)
             || string.IsNullOrWhiteSpace(strType) || string.IsNullOrWhiteSpace(strName)  || string.IsNullOrWhiteSpace(strCode))
            {
                return false;
            }
            
            return true;
        }
        private bool saveHeader()
        {
            string strQuery =
                "INSERT INTO tblBranchDistribution VALUES " +
                "('" + strDCode + "', '" + strDate + "');";
            if (!Program.ExecuteQuery(strQuery))
            {
                MetroMessageBox.Show(this, "Failed to save to database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        private bool saveCampusDetail()
        {
            getSelectedCampus();
            string strQuery;
            foreach(string strBranch in campus)
            {
                strQuery=
                    "INSERT INTO tblbrancampusdetail VALUES " +
                    "('" + strDCode + "', '" + strBranch + "');";
                 if (!Program.ExecuteQuery(strQuery))
                 {
                     MetroMessageBox.Show(this, "Failed to save "+strBranch+" to database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                //MessageBox.Show(strQuery);
            }
            return true;
                
        }
        private bool saveItemDetail()
        {
            string strQuery =
                "INSERT INTO tblBranItemDetail VALUES " +
                "('"+strDCode+"', '"+strCode+"', "+strQty+", "+cbUOM.SelectedIndex.ToString() +");";
            if (!Program.ExecuteQuery(strQuery))
            {
                 MetroMessageBox.Show(this, "Failed to save Item Detail to database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            //MessageBox.Show(strQuery);
            return true;
        }
        private void cbName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbName.SelectedIndex <= alistCode.Count && alistCode != null)
            {
                txtCode.Text = alistCode[cbName.SelectedIndex].ToString();
                getBalance(txtCode.Text);
                getIntValues();
            }
        }
        private void loadItemComboBox(int type)
        {
            if (!mn.fillComboBox(cbName, "SELECT strItemCode, strItemName FROM tblItem WHERE fnGetBalance(strItemCode)>0 AND intItemType=" + type + " AND boolItemDeleted=FALSE;", out alistCode))
            {
                cbName.Enabled = false;
                txtCode.Text = "";
            }
            else
            {
                cbName.Enabled = true;
                txtCode.Text = alistCode[0].ToString();
            }
            cbName.SelectedIndex = 0;

        }
        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!mn.fillComboBox(cbName, "SELECT strItemCode, strItemName FROM tblItem WHERE fnGetBalance(strItemCode)>0 AND intItemType=" + (cbType.SelectedIndex + 1) + " AND boolItemDeleted=FALSE;", out alistCode))
            {
                cbName.Enabled = false;
                status.Text = "No available item";
                status.BackColor = Color.Tomato;
            }
            else
            {
                cbName.Enabled = true;
                cbName.SelectedIndex = 0;
                status.Text = "";
                status.BackColor = Color.DarkCyan;
            }
        }
        private void loadBranches()
        {
            cbBranch.Items.Clear();
            try
            {
                if (Program.conn != null && Program.conn.State == ConnectionState.Closed)
                    Program.conn.Open();
                using (MySqlCommand cmd = new MySqlCommand("SELECT * FROM tblbranch;", Program.conn))
                {
                    using (MySqlDataReader dataReader = cmd.ExecuteReader())
                    {
                        //Read the data and store them in the list
                        while (dataReader.Read())
                        {
                            campuscode.Add(dataReader.GetString(0));
                            cbBranch.Items.Add(dataReader.GetString(1));
                        }
                        dataReader.Close();
                    }
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Program.conn.Close();
            }
        }
    }
}
