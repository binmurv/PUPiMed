﻿namespace PUPiMed
{
    partial class FormAddDistribItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAddDistribItem));
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.txtAvailable = new MetroFramework.Controls.MetroTextBox();
            this.txtQty = new MetroFramework.Controls.MetroTextBox();
            this.cbUOM = new MetroFramework.Controls.MetroComboBox();
            this.txtTotal = new MetroFramework.Controls.MetroTextBox();
            this.txtBalance = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new MetroFramework.Controls.MetroButton();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.cbName = new MetroFramework.Controls.MetroComboBox();
            this.cbType = new MetroFramework.Controls.MetroComboBox();
            this.title = new System.Windows.Forms.Label();
            this.dtDate = new MetroFramework.Controls.MetroDateTime();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.status = new MetroFramework.Controls.MetroTile();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.materialDivider2 = new MaterialSkin.Controls.MaterialDivider();
            this.lblCode = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.materialDivider1 = new MaterialSkin.Controls.MaterialDivider();
            this.txtBranch = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.pbAddItem = new System.Windows.Forms.PictureBox();
            this.cbBranch = new System.Windows.Forms.CheckedListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddItem)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCode
            // 
            this.txtCode.AccessibleName = "fname";
            this.txtCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCode.Enabled = false;
            this.txtCode.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(618, 273);
            this.txtCode.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtCode.MaxLength = 32767;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.Size = new System.Drawing.Size(186, 26);
            this.txtCode.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtCode.TabIndex = 0;
            this.txtCode.UseCustomBackColor = true;
            this.txtCode.UseSelectable = true;
            this.txtCode.Click += new System.EventHandler(this.txtCode_Click);
            // 
            // txtAvailable
            // 
            this.txtAvailable.AccessibleName = "fname";
            this.txtAvailable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAvailable.Enabled = false;
            this.txtAvailable.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtAvailable.Lines = new string[] {
        "0"};
            this.txtAvailable.Location = new System.Drawing.Point(618, 312);
            this.txtAvailable.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtAvailable.MaxLength = 32767;
            this.txtAvailable.Name = "txtAvailable";
            this.txtAvailable.PasswordChar = '\0';
            this.txtAvailable.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAvailable.SelectedText = "";
            this.txtAvailable.Size = new System.Drawing.Size(186, 26);
            this.txtAvailable.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtAvailable.TabIndex = 0;
            this.txtAvailable.Text = "0";
            this.txtAvailable.UseCustomBackColor = true;
            this.txtAvailable.UseSelectable = true;
            this.txtAvailable.Click += new System.EventHandler(this.txtAvailable_Click);
            // 
            // txtQty
            // 
            this.txtQty.AccessibleName = "fname";
            this.txtQty.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtQty.Lines = new string[] {
        "0"};
            this.txtQty.Location = new System.Drawing.Point(618, 390);
            this.txtQty.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtQty.MaxLength = 32767;
            this.txtQty.Name = "txtQty";
            this.txtQty.PasswordChar = '\0';
            this.txtQty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtQty.SelectedText = "";
            this.txtQty.Size = new System.Drawing.Size(186, 26);
            this.txtQty.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtQty.TabIndex = 40;
            this.txtQty.Text = "0";
            this.txtQty.UseCustomBackColor = true;
            this.txtQty.UseSelectable = true;
            this.txtQty.TextChanged += new System.EventHandler(this.txtQty_TextChanged);
            this.txtQty.Click += new System.EventHandler(this.txtQty_Click);
            // 
            // cbUOM
            // 
            this.cbUOM.AccessibleName = "ptype";
            this.cbUOM.DisplayMember = "0";
            this.cbUOM.FormattingEnabled = true;
            this.cbUOM.ItemHeight = 23;
            this.cbUOM.Items.AddRange(new object[] {
            "Box",
            "Piece"});
            this.cbUOM.Location = new System.Drawing.Point(618, 351);
            this.cbUOM.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.cbUOM.Name = "cbUOM";
            this.cbUOM.Size = new System.Drawing.Size(184, 29);
            this.cbUOM.Style = MetroFramework.MetroColorStyle.Teal;
            this.cbUOM.TabIndex = 41;
            this.cbUOM.UseSelectable = true;
            this.cbUOM.SelectedIndexChanged += new System.EventHandler(this.UOM_SelectedIndexChanged);
            // 
            // txtTotal
            // 
            this.txtTotal.AccessibleName = "fname";
            this.txtTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTotal.Enabled = false;
            this.txtTotal.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtTotal.Lines = new string[] {
        "0"};
            this.txtTotal.Location = new System.Drawing.Point(618, 429);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtTotal.MaxLength = 32767;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.PasswordChar = '\0';
            this.txtTotal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTotal.SelectedText = "";
            this.txtTotal.Size = new System.Drawing.Size(186, 26);
            this.txtTotal.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtTotal.TabIndex = 0;
            this.txtTotal.Text = "0";
            this.txtTotal.UseCustomBackColor = true;
            this.txtTotal.UseSelectable = true;
            this.txtTotal.Click += new System.EventHandler(this.txtTotal_Click);
            // 
            // txtBalance
            // 
            this.txtBalance.AccessibleName = "fname";
            this.txtBalance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtBalance.Enabled = false;
            this.txtBalance.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtBalance.Lines = new string[] {
        "0"};
            this.txtBalance.Location = new System.Drawing.Point(618, 468);
            this.txtBalance.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtBalance.MaxLength = 32767;
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.PasswordChar = '\0';
            this.txtBalance.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBalance.SelectedText = "";
            this.txtBalance.Size = new System.Drawing.Size(186, 26);
            this.txtBalance.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtBalance.TabIndex = 0;
            this.txtBalance.Text = "0";
            this.txtBalance.UseCustomBackColor = true;
            this.txtBalance.UseSelectable = true;
            this.txtBalance.Click += new System.EventHandler(this.txtBalance_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AccessibleName = "ptype";
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(54, 150);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(203, 25);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel3.TabIndex = 69;
            this.metroLabel3.Text = "Branches / Campuses :";
            // 
            // btnCancel
            // 
            this.btnCancel.AccessibleName = "btncancel";
            this.btnCancel.BackColor = System.Drawing.Color.White;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Highlight = true;
            this.btnCancel.Location = new System.Drawing.Point(666, 566);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(102, 39);
            this.btnCancel.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCancel.TabIndex = 88;
            this.btnCancel.Text = "     Cancel";
            this.btnCancel.UseCustomBackColor = true;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.UseStyleColors = true;
            this.btnCancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AccessibleName = "btnadd";
            this.btnAdd.Highlight = true;
            this.btnAdd.Location = new System.Drawing.Point(564, 566);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(102, 39);
            this.btnAdd.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnAdd.TabIndex = 86;
            this.btnAdd.Text = "   Add";
            this.btnAdd.UseCustomBackColor = true;
            this.btnAdd.UseSelectable = true;
            this.btnAdd.UseStyleColors = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // cbName
            // 
            this.cbName.FormattingEnabled = true;
            this.cbName.ItemHeight = 23;
            this.cbName.Location = new System.Drawing.Point(618, 234);
            this.cbName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.cbName.Name = "cbName";
            this.cbName.Size = new System.Drawing.Size(184, 29);
            this.cbName.Style = MetroFramework.MetroColorStyle.Teal;
            this.cbName.TabIndex = 106;
            this.cbName.UseSelectable = true;
            this.cbName.UseStyleColors = true;
            this.cbName.SelectedIndexChanged += new System.EventHandler(this.cbName_SelectedIndexChanged);
            // 
            // cbType
            // 
            this.cbType.DisplayMember = "0";
            this.cbType.FormattingEnabled = true;
            this.cbType.ItemHeight = 23;
            this.cbType.Items.AddRange(new object[] {
            "Medicine",
            "Supply",
            "Equipment"});
            this.cbType.Location = new System.Drawing.Point(618, 195);
            this.cbType.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(184, 29);
            this.cbType.Style = MetroFramework.MetroColorStyle.Teal;
            this.cbType.TabIndex = 105;
            this.cbType.Theme = MetroFramework.MetroThemeStyle.Light;
            this.cbType.UseSelectable = true;
            this.cbType.UseStyleColors = true;
            this.cbType.ValueMember = "Medicine";
            this.cbType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            // 
            // title
            // 
            this.title.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.title.Location = new System.Drawing.Point(312, 52);
            this.title.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(360, 58);
            this.title.TabIndex = 107;
            this.title.Text = "ADD ITEM TO DISTRIBUTE";
            this.title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtDate
            // 
            this.dtDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDate.Location = new System.Drawing.Point(618, 507);
            this.dtDate.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.dtDate.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtDate.Name = "dtDate";
            this.dtDate.Size = new System.Drawing.Size(184, 29);
            this.dtDate.TabIndex = 109;
            this.dtDate.ValueChanged += new System.EventHandler(this.dtDate_ValueChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::PUPiMed.Properties.Resources.cancel_teal_box;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(672, 572);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 89;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::PUPiMed.Properties.Resources.add_teal_box;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(570, 572);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 26);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 87;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::PUPiMed.Properties.Resources.truck_100px;
            this.pictureBox12.Location = new System.Drawing.Point(198, 26);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(108, 91);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 85;
            this.pictureBox12.TabStop = false;
            // 
            // status
            // 
            this.status.ActiveControl = null;
            this.status.BackColor = System.Drawing.Color.DarkCyan;
            this.status.Location = new System.Drawing.Point(0, 124);
            this.status.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(870, 13);
            this.status.TabIndex = 101;
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.status.UseCustomBackColor = true;
            this.status.UseSelectable = true;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.BackColor = System.Drawing.Color.DarkCyan;
            this.metroTile1.Location = new System.Drawing.Point(0, 26);
            this.metroTile1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(870, 13);
            this.metroTile1.TabIndex = 111;
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile1.UseCustomBackColor = true;
            this.metroTile1.UseSelectable = true;
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.metroTile2.Location = new System.Drawing.Point(0, 58);
            this.metroTile2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(186, 52);
            this.metroTile2.TabIndex = 112;
            this.metroTile2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile2.UseCustomBackColor = true;
            this.metroTile2.UseSelectable = true;
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.metroTile3.Location = new System.Drawing.Point(678, 58);
            this.metroTile3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(192, 52);
            this.metroTile3.TabIndex = 113;
            this.metroTile3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile3.UseCustomBackColor = true;
            this.metroTile3.UseSelectable = true;
            // 
            // materialDivider2
            // 
            this.materialDivider2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.materialDivider2.Depth = 0;
            this.materialDivider2.Location = new System.Drawing.Point(462, 162);
            this.materialDivider2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.materialDivider2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDivider2.Name = "materialDivider2";
            this.materialDivider2.Size = new System.Drawing.Size(378, 455);
            this.materialDivider2.TabIndex = 128;
            this.materialDivider2.Text = "materialDivider2";
            // 
            // lblCode
            // 
            this.lblCode.AccessibleName = "";
            this.lblCode.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblCode.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblCode.Location = new System.Drawing.Point(504, 202);
            this.lblCode.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(84, 20);
            this.lblCode.TabIndex = 117;
            this.lblCode.Text = "Item Type :";
            this.lblCode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblCode.UseCustomBackColor = true;
            this.lblCode.Click += new System.EventHandler(this.lblCode_Click);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AccessibleName = "";
            this.metroLabel8.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel8.Location = new System.Drawing.Point(504, 240);
            this.metroLabel8.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(84, 20);
            this.metroLabel8.TabIndex = 129;
            this.metroLabel8.Text = "Item Name :";
            this.metroLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel8.UseCustomBackColor = true;
            this.metroLabel8.Click += new System.EventHandler(this.metroLabel8_Click_1);
            // 
            // metroLabel11
            // 
            this.metroLabel11.AccessibleName = "";
            this.metroLabel11.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel11.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel11.Location = new System.Drawing.Point(504, 280);
            this.metroLabel11.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(84, 20);
            this.metroLabel11.TabIndex = 130;
            this.metroLabel11.Text = "Item Code :";
            this.metroLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel11.UseCustomBackColor = true;
            this.metroLabel11.Click += new System.EventHandler(this.metroLabel11_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AccessibleName = "";
            this.metroLabel1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(504, 318);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(84, 20);
            this.metroLabel1.TabIndex = 131;
            this.metroLabel1.Text = "Available :";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel1.UseCustomBackColor = true;
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click_1);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AccessibleName = "";
            this.metroLabel2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(504, 396);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(84, 20);
            this.metroLabel2.TabIndex = 132;
            this.metroLabel2.Text = "Quantity :";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel2_Click_1);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AccessibleName = "";
            this.metroLabel4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(504, 358);
            this.metroLabel4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(54, 20);
            this.metroLabel4.TabIndex = 133;
            this.metroLabel4.Text = "UOM :";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.Click += new System.EventHandler(this.metroLabel4_Click_1);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AccessibleName = "";
            this.metroLabel5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(504, 514);
            this.metroLabel5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(84, 20);
            this.metroLabel5.TabIndex = 134;
            this.metroLabel5.Text = "Date :";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.Click += new System.EventHandler(this.metroLabel5_Click);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AccessibleName = "";
            this.metroLabel6.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(504, 436);
            this.metroLabel6.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(84, 20);
            this.metroLabel6.TabIndex = 135;
            this.metroLabel6.Text = "Total :";
            this.metroLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel6.UseCustomBackColor = true;
            this.metroLabel6.Click += new System.EventHandler(this.metroLabel6_Click);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AccessibleName = "";
            this.metroLabel7.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(504, 474);
            this.metroLabel7.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(84, 20);
            this.metroLabel7.TabIndex = 136;
            this.metroLabel7.Text = "Balance :";
            this.metroLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.Click += new System.EventHandler(this.metroLabel7_Click);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AccessibleName = "ptype";
            this.metroLabel9.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel9.Location = new System.Drawing.Point(504, 150);
            this.metroLabel9.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(168, 26);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroLabel9.TabIndex = 137;
            this.metroLabel9.Text = "Item Information :";
            // 
            // materialDivider1
            // 
            this.materialDivider1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.materialDivider1.Depth = 0;
            this.materialDivider1.Location = new System.Drawing.Point(24, 162);
            this.materialDivider1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.materialDivider1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDivider1.Name = "materialDivider1";
            this.materialDivider1.Size = new System.Drawing.Size(414, 455);
            this.materialDivider1.TabIndex = 138;
            this.materialDivider1.Text = "materialDivider1";
            // 
            // txtBranch
            // 
            this.txtBranch.AccessibleName = "fname";
            this.txtBranch.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtBranch.Lines = new string[0];
            this.txtBranch.Location = new System.Drawing.Point(156, 202);
            this.txtBranch.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.txtBranch.MaxLength = 32767;
            this.txtBranch.Name = "txtBranch";
            this.txtBranch.PasswordChar = '\0';
            this.txtBranch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBranch.SelectedText = "";
            this.txtBranch.Size = new System.Drawing.Size(216, 26);
            this.txtBranch.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtBranch.TabIndex = 139;
            this.txtBranch.UseCustomBackColor = true;
            this.txtBranch.UseSelectable = true;
            this.txtBranch.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AccessibleName = "";
            this.metroLabel10.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel10.Location = new System.Drawing.Point(54, 208);
            this.metroLabel10.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(96, 20);
            this.metroLabel10.TabIndex = 140;
            this.metroLabel10.Text = "Add Branch :";
            this.metroLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroLabel10.UseCustomBackColor = true;
            // 
            // pbAddItem
            // 
            this.pbAddItem.BackColor = System.Drawing.Color.Transparent;
            this.pbAddItem.BackgroundImage = global::PUPiMed.Properties.Resources.add_teal_box;
            this.pbAddItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbAddItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbAddItem.Location = new System.Drawing.Point(378, 202);
            this.pbAddItem.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.pbAddItem.Name = "pbAddItem";
            this.pbAddItem.Size = new System.Drawing.Size(30, 26);
            this.pbAddItem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAddItem.TabIndex = 141;
            this.pbAddItem.TabStop = false;
            this.pbAddItem.Click += new System.EventHandler(this.pbAddItem_Click);
            // 
            // cbBranch
            // 
            this.cbBranch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cbBranch.CheckOnClick = true;
            this.cbBranch.ColumnWidth = 180;
            this.cbBranch.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBranch.ForeColor = System.Drawing.Color.Black;
            this.cbBranch.FormattingEnabled = true;
            this.cbBranch.Location = new System.Drawing.Point(54, 240);
            this.cbBranch.Name = "cbBranch";
            this.cbBranch.Size = new System.Drawing.Size(354, 330);
            this.cbBranch.TabIndex = 0;
            this.cbBranch.ThreeDCheckBoxes = true;
            this.cbBranch.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.cbBranch_ItemCheck);
            this.cbBranch.Click += new System.EventHandler(this.materialCheckBox5_CheckStateChanged);
            this.cbBranch.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cbBranch_MouseClick_1);
            this.cbBranch.Enter += new System.EventHandler(this.cbBranch_Enter);
            this.cbBranch.MouseEnter += new System.EventHandler(this.cbBranch_MouseEnter);
            // 
            // FormAddDistribItem
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(864, 644);
            this.Controls.Add(this.cbBranch);
            this.Controls.Add(this.pbAddItem);
            this.Controls.Add(this.metroLabel10);
            this.Controls.Add(this.txtBranch);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.lblCode);
            this.Controls.Add(this.metroTile3);
            this.Controls.Add(this.metroTile1);
            this.Controls.Add(this.dtDate);
            this.Controls.Add(this.cbName);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.status);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.cbUOM);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.txtAvailable);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.title);
            this.Controls.Add(this.metroTile2);
            this.Controls.Add(this.materialDivider2);
            this.Controls.Add(this.materialDivider1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Transparent;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.MaximizeBox = false;
            this.Name = "FormAddDistribItem";
            this.Padding = new System.Windows.Forms.Padding(18, 60, 18, 20);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Teal;
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.Load += new System.EventHandler(this.FormAddDistribItem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAddItem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroTextBox txtCode;
        private MetroFramework.Controls.MetroTextBox txtAvailable;
        private MetroFramework.Controls.MetroTextBox txtQty;
        private MetroFramework.Controls.MetroComboBox cbUOM;
        private MetroFramework.Controls.MetroTextBox txtTotal;
        private MetroFramework.Controls.MetroTextBox txtBalance;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroButton btnCancel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroComboBox cbName;
        private MetroFramework.Controls.MetroComboBox cbType;
        private System.Windows.Forms.Label title;
        private MetroFramework.Controls.MetroDateTime dtDate;
        private MetroFramework.Controls.MetroTile status;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroTile metroTile2;
        private MetroFramework.Controls.MetroTile metroTile3;
        private MaterialSkin.Controls.MaterialDivider materialDivider2;
        private MetroFramework.Controls.MetroLabel lblCode;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MaterialSkin.Controls.MaterialDivider materialDivider1;
        private MetroFramework.Controls.MetroTextBox txtBranch;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.PictureBox pbAddItem;
        private System.Windows.Forms.CheckedListBox cbBranch;
    }
}