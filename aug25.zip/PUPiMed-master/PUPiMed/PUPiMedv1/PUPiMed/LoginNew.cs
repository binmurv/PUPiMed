﻿using MetroFramework.Forms;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PUPiMed
{
    public partial class LoginNew : MetroForm
    {
        public LoginNew()
        {
            InitializeComponent();
        }

        private void btnLOGIN_Click(object sender, EventArgs e)
        {
            login(txtUser.Text, txtPass.Text);
        }

        public void login(string user, string pass)
        {
            user = user+";";
            pass = pass + ";";
            try
            {
                conn.ConnectionString =
                    "server = " + server +
                    "user id =" + user +
                    "password=" + pass +
                    "database=" + db;
                LoginNew.conn.Open();
                if (LoginNew.conn != null && (LoginNew.conn.State == ConnectionState.Open))
                {
                    MessageBox.Show("Oks na. Wait lang u.");
                    this.Hide();
                    new MainForm().Show();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            
        }

        public static MySqlConnection conn = new MySqlConnection();
        static string server = "localhost;";
        static string user;
        static string pass;
        static string db = "dbmedicalclinic;";


        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginNew());
        }
    }
}
