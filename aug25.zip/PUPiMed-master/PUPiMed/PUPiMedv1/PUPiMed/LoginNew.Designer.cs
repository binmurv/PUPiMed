﻿namespace PUPiMed
{
    partial class LoginNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginNew));
            this.txtUser = new MetroFramework.Controls.MetroTextBox();
            this.txtPass = new MetroFramework.Controls.MetroTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Login = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtUser
            // 
            this.txtUser.AccessibleName = "boxUserID";
            this.txtUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUser.Icon = global::PUPiMed.Properties.Resources.businessman_50px;
            this.txtUser.Lines = new string[0];
            this.txtUser.Location = new System.Drawing.Point(101, 356);
            this.txtUser.MaxLength = 32767;
            this.txtUser.Name = "txtUser";
            this.txtUser.PasswordChar = '\0';
            this.txtUser.PromptText = "Username";
            this.txtUser.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUser.SelectedText = "";
            this.txtUser.Size = new System.Drawing.Size(251, 23);
            this.txtUser.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtUser.TabIndex = 3;
            this.txtUser.UseCustomBackColor = true;
            this.txtUser.UseSelectable = true;
            this.txtUser.UseStyleColors = true;
            // 
            // txtPass
            // 
            this.txtPass.AccessibleName = "boxPassCode";
            this.txtPass.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPass.Icon = global::PUPiMed.Properties.Resources.key_45px;
            this.txtPass.Lines = new string[0];
            this.txtPass.Location = new System.Drawing.Point(101, 412);
            this.txtPass.MaxLength = 32767;
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '●';
            this.txtPass.PromptText = "Password";
            this.txtPass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPass.SelectedText = "";
            this.txtPass.Size = new System.Drawing.Size(251, 23);
            this.txtPass.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtPass.TabIndex = 4;
            this.txtPass.UseCustomBackColor = true;
            this.txtPass.UseSelectable = true;
            this.txtPass.UseStyleColors = true;
            this.txtPass.UseSystemPasswordChar = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PUPiMed.Properties.Resources.log_in_background_with_logo;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(452, 620);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Login
            // 
            this.Login.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Login.Highlight = true;
            this.Login.Location = new System.Drawing.Point(181, 465);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(93, 39);
            this.Login.Style = MetroFramework.MetroColorStyle.Teal;
            this.Login.TabIndex = 12;
            this.Login.Text = "Login";
            this.Login.UseCustomBackColor = true;
            this.Login.UseSelectable = true;
            this.Login.UseStyleColors = true;
            this.Login.Click += new System.EventHandler(this.btnLOGIN_Click);
            // 
            // LoginNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PUPiMed.Properties.Resources.log_in_background3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BackImage = global::PUPiMed.Properties.Resources.log_in_background3;
            this.ClientSize = new System.Drawing.Size(450, 623);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.txtPass);
            this.Controls.Add(this.pictureBox1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.MaximizeBox = false;
            this.Movable = false;
            this.Name = "LoginNew";
            this.Resizable = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Style = MetroFramework.MetroColorStyle.Teal;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        public MetroFramework.Controls.MetroTextBox txtUser;
        public MetroFramework.Controls.MetroTextBox txtPass;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroButton Login;
    }
}