﻿namespace PUPiMed
{
    partial class FormAddSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAddSupplier));
            this.txtEmail = new MetroFramework.Controls.MetroTextBox();
            this.lblManuName = new MetroFramework.Controls.MetroLabel();
            this.txtStreet = new MetroFramework.Controls.MetroTextBox();
            this.lblother = new MetroFramework.Controls.MetroLabel();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new MetroFramework.Controls.MetroButton();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.suppcode = new MetroFramework.Controls.MetroLabel();
            this.txtCode = new MetroFramework.Controls.MetroTextBox();
            this.txtContact = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txtCity = new MetroFramework.Controls.MetroTextBox();
            this.txtTown = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtNo = new MetroFramework.Controls.MetroTextBox();
            this.status = new MetroFramework.Controls.MetroTile();
            this.title = new System.Windows.Forms.Label();
            this.icon = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.materialDivider2 = new MaterialSkin.Controls.MaterialDivider();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.materialDivider1 = new MaterialSkin.Controls.MaterialDivider();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.icon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtEmail
            // 
            this.txtEmail.AccessibleName = "";
            this.txtEmail.BackColor = System.Drawing.Color.White;
            this.txtEmail.Lines = new string[0];
            this.txtEmail.Location = new System.Drawing.Point(364, 221);
            this.txtEmail.MaxLength = 32767;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.PasswordChar = '\0';
            this.txtEmail.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtEmail.SelectedText = "";
            this.txtEmail.Size = new System.Drawing.Size(211, 23);
            this.txtEmail.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtEmail.TabIndex = 135;
            this.txtEmail.UseCustomBackColor = true;
            this.txtEmail.UseSelectable = true;
            this.txtEmail.Click += new System.EventHandler(this.txtCode_Click);
            this.txtEmail.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // lblManuName
            // 
            this.lblManuName.AccessibleName = "lblmed";
            this.lblManuName.AutoSize = true;
            this.lblManuName.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblManuName.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblManuName.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblManuName.Location = new System.Drawing.Point(250, 223);
            this.lblManuName.Name = "lblManuName";
            this.lblManuName.Size = new System.Drawing.Size(87, 15);
            this.lblManuName.TabIndex = 129;
            this.lblManuName.Text = "Email Address :";
            this.lblManuName.UseCustomBackColor = true;
            // 
            // txtStreet
            // 
            this.txtStreet.AccessibleName = "";
            this.txtStreet.BackColor = System.Drawing.Color.White;
            this.txtStreet.Lines = new string[0];
            this.txtStreet.Location = new System.Drawing.Point(478, 318);
            this.txtStreet.MaxLength = 32767;
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.PasswordChar = '\0';
            this.txtStreet.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtStreet.SelectedText = "";
            this.txtStreet.Size = new System.Drawing.Size(97, 23);
            this.txtStreet.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtStreet.TabIndex = 137;
            this.txtStreet.UseCustomBackColor = true;
            this.txtStreet.UseSelectable = true;
            this.txtStreet.Click += new System.EventHandler(this.txtCode_Click);
            this.txtStreet.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // lblother
            // 
            this.lblother.AccessibleName = "lblother";
            this.lblother.AutoSize = true;
            this.lblother.BackColor = System.Drawing.Color.PaleTurquoise;
            this.lblother.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblother.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblother.Location = new System.Drawing.Point(251, 183);
            this.lblother.Name = "lblother";
            this.lblother.Size = new System.Drawing.Size(77, 15);
            this.lblother.TabIndex = 126;
            this.lblother.Text = "Contact No. :";
            this.lblother.UseCustomBackColor = true;
            this.lblother.Click += new System.EventHandler(this.lblother_Click);
            // 
            // txtName
            // 
            this.txtName.AccessibleName = "";
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(364, 141);
            this.txtName.MaxLength = 32767;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.Size = new System.Drawing.Size(211, 23);
            this.txtName.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtName.TabIndex = 133;
            this.txtName.UseCustomBackColor = true;
            this.txtName.UseSelectable = true;
            this.txtName.Click += new System.EventHandler(this.txtCode_Click);
            this.txtName.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AccessibleName = "lblmed";
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel1.Location = new System.Drawing.Point(250, 143);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(45, 15);
            this.metroLabel1.TabIndex = 124;
            this.metroLabel1.Text = "Name :";
            this.metroLabel1.UseCustomBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.AccessibleName = "btncancel";
            this.btnCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancel.BackColor = System.Drawing.Color.White;
            this.btnCancel.Highlight = true;
            this.btnCancel.Location = new System.Drawing.Point(421, 454);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 37);
            this.btnCancel.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnCancel.TabIndex = 141;
            this.btnCancel.Text = "     Cancel";
            this.btnCancel.UseCustomBackColor = true;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.UseStyleColors = true;
            this.btnCancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AccessibleName = "btnadd";
            this.btnAdd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAdd.Highlight = true;
            this.btnAdd.Location = new System.Drawing.Point(302, 454);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(99, 37);
            this.btnAdd.Style = MetroFramework.MetroColorStyle.Teal;
            this.btnAdd.TabIndex = 140;
            this.btnAdd.Text = "   Save";
            this.btnAdd.UseCustomBackColor = true;
            this.btnAdd.UseSelectable = true;
            this.btnAdd.UseStyleColors = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // suppcode
            // 
            this.suppcode.AccessibleName = "suppcode";
            this.suppcode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.suppcode.AutoSize = true;
            this.suppcode.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.suppcode.Location = new System.Drawing.Point(63, 296);
            this.suppcode.Name = "suppcode";
            this.suppcode.Size = new System.Drawing.Size(101, 19);
            this.suppcode.Style = MetroFramework.MetroColorStyle.Teal;
            this.suppcode.TabIndex = 133;
            this.suppcode.Text = "Supplier Code :";
            // 
            // txtCode
            // 
            this.txtCode.AccessibleName = "Eqcode";
            this.txtCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCode.Lines = new string[0];
            this.txtCode.Location = new System.Drawing.Point(34, 321);
            this.txtCode.MaxLength = 32767;
            this.txtCode.Name = "txtCode";
            this.txtCode.PasswordChar = '\0';
            this.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCode.SelectedText = "";
            this.txtCode.Size = new System.Drawing.Size(163, 23);
            this.txtCode.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtCode.TabIndex = 132;
            this.txtCode.UseSelectable = true;
            this.txtCode.Click += new System.EventHandler(this.txtCode_Click);
            // 
            // txtContact
            // 
            this.txtContact.AccessibleName = "";
            this.txtContact.BackColor = System.Drawing.Color.White;
            this.txtContact.Lines = new string[0];
            this.txtContact.Location = new System.Drawing.Point(364, 181);
            this.txtContact.MaxLength = 32767;
            this.txtContact.Name = "txtContact";
            this.txtContact.PasswordChar = '\0';
            this.txtContact.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtContact.SelectedText = "";
            this.txtContact.Size = new System.Drawing.Size(211, 23);
            this.txtContact.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtContact.TabIndex = 134;
            this.txtContact.UseCustomBackColor = true;
            this.txtContact.UseSelectable = true;
            this.txtContact.Click += new System.EventHandler(this.txtCode_Click);
            this.txtContact.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AccessibleName = "lbltype";
            this.metroLabel2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(421, 320);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(57, 19);
            this.metroLabel2.TabIndex = 135;
            this.metroLabel2.Text = "Street :";
            this.metroLabel2.UseCustomBackColor = true;
            this.metroLabel2.UseCustomForeColor = true;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AccessibleName = "lbltype";
            this.metroLabel3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(250, 360);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(111, 19);
            this.metroLabel3.TabIndex = 136;
            this.metroLabel3.Text = "Town/Brgy :";
            this.metroLabel3.UseCustomBackColor = true;
            this.metroLabel3.UseCustomForeColor = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AccessibleName = "lbltype";
            this.metroLabel4.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(250, 400);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(108, 19);
            this.metroLabel4.TabIndex = 137;
            this.metroLabel4.Text = "City/Province :";
            this.metroLabel4.UseCustomBackColor = true;
            this.metroLabel4.UseCustomForeColor = true;
            // 
            // txtCity
            // 
            this.txtCity.AccessibleName = "";
            this.txtCity.BackColor = System.Drawing.Color.White;
            this.txtCity.Lines = new string[0];
            this.txtCity.Location = new System.Drawing.Point(364, 398);
            this.txtCity.MaxLength = 32767;
            this.txtCity.Name = "txtCity";
            this.txtCity.PasswordChar = '\0';
            this.txtCity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCity.SelectedText = "";
            this.txtCity.Size = new System.Drawing.Size(211, 23);
            this.txtCity.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtCity.TabIndex = 139;
            this.txtCity.UseCustomBackColor = true;
            this.txtCity.UseSelectable = true;
            this.txtCity.Click += new System.EventHandler(this.txtCode_Click);
            this.txtCity.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // txtTown
            // 
            this.txtTown.AccessibleName = "";
            this.txtTown.BackColor = System.Drawing.Color.White;
            this.txtTown.Lines = new string[0];
            this.txtTown.Location = new System.Drawing.Point(364, 358);
            this.txtTown.MaxLength = 32767;
            this.txtTown.Name = "txtTown";
            this.txtTown.PasswordChar = '\0';
            this.txtTown.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTown.SelectedText = "";
            this.txtTown.Size = new System.Drawing.Size(211, 23);
            this.txtTown.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtTown.TabIndex = 138;
            this.txtTown.UseCustomBackColor = true;
            this.txtTown.UseSelectable = true;
            this.txtTown.Click += new System.EventHandler(this.txtCode_Click);
            this.txtTown.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AccessibleName = "lbltype";
            this.metroLabel5.BackColor = System.Drawing.Color.PaleTurquoise;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(250, 320);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(111, 19);
            this.metroLabel5.TabIndex = 140;
            this.metroLabel5.Text = "Building # :";
            this.metroLabel5.UseCustomBackColor = true;
            this.metroLabel5.UseCustomForeColor = true;
            // 
            // txtNo
            // 
            this.txtNo.AccessibleName = "";
            this.txtNo.BackColor = System.Drawing.Color.White;
            this.txtNo.Lines = new string[0];
            this.txtNo.Location = new System.Drawing.Point(364, 318);
            this.txtNo.MaxLength = 32767;
            this.txtNo.Name = "txtNo";
            this.txtNo.PasswordChar = '\0';
            this.txtNo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNo.SelectedText = "";
            this.txtNo.Size = new System.Drawing.Size(51, 23);
            this.txtNo.Style = MetroFramework.MetroColorStyle.Teal;
            this.txtNo.TabIndex = 136;
            this.txtNo.UseCustomBackColor = true;
            this.txtNo.UseSelectable = true;
            this.txtNo.Click += new System.EventHandler(this.txtCode_Click);
            this.txtNo.Enter += new System.EventHandler(this.txtCode_Click);
            // 
            // status
            // 
            this.status.ActiveControl = null;
            this.status.BackColor = System.Drawing.Color.DarkCyan;
            this.status.Location = new System.Drawing.Point(0, 68);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(633, 29);
            this.status.TabIndex = 143;
            this.status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.status.UseCustomBackColor = true;
            this.status.UseSelectable = true;
            // 
            // title
            // 
            this.title.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.title.Location = new System.Drawing.Point(-4, 6);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(636, 71);
            this.title.TabIndex = 145;
            this.title.Text = "SUPPLIER";
            this.title.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // icon
            // 
            this.icon.BackColor = System.Drawing.Color.White;
            this.icon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.icon.Image = global::PUPiMed.Properties.Resources.supplier_icon;
            this.icon.Location = new System.Drawing.Point(33, 121);
            this.icon.Name = "icon";
            this.icon.Size = new System.Drawing.Size(164, 162);
            this.icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.icon.TabIndex = 144;
            this.icon.TabStop = false;
            this.icon.Click += new System.EventHandler(this.icon_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.BackgroundImage = global::PUPiMed.Properties.Resources.cancel_teal_box;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(426, 459);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 26);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 123;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::PUPiMed.Properties.Resources.add_teal_box;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(307, 459);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(26, 26);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 122;
            this.pictureBox1.TabStop = false;
            // 
            // materialDivider2
            // 
            this.materialDivider2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.materialDivider2.Depth = 0;
            this.materialDivider2.Location = new System.Drawing.Point(231, 295);
            this.materialDivider2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDivider2.Name = "materialDivider2";
            this.materialDivider2.Size = new System.Drawing.Size(365, 141);
            this.materialDivider2.TabIndex = 146;
            this.materialDivider2.Text = "materialDivider2";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AccessibleName = "lblmed";
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.Location = new System.Drawing.Point(250, 281);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(71, 19);
            this.metroLabel6.TabIndex = 147;
            this.metroLabel6.Text = "Address :";
            // 
            // materialDivider1
            // 
            this.materialDivider1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.materialDivider1.Depth = 0;
            this.materialDivider1.Location = new System.Drawing.Point(231, 121);
            this.materialDivider1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialDivider1.Name = "materialDivider1";
            this.materialDivider1.Size = new System.Drawing.Size(365, 144);
            this.materialDivider1.TabIndex = 148;
            this.materialDivider1.Text = "materialDivider1";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AccessibleName = "lblmed";
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(251, 109);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(103, 19);
            this.metroLabel7.TabIndex = 149;
            this.metroLabel7.Text = "Supplier Info :";
            // 
            // FormAddSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 514);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.icon);
            this.Controls.Add(this.status);
            this.Controls.Add(this.txtNo);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtTown);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.suppcode);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblManuName);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.lblother);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.title);
            this.Controls.Add(this.materialDivider2);
            this.Controls.Add(this.materialDivider1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAddSupplier";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Teal;
            ((System.ComponentModel.ISupportInitialize)(this.icon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public MetroFramework.Controls.MetroTextBox txtEmail;
        private MetroFramework.Controls.MetroLabel lblManuName;
        public MetroFramework.Controls.MetroTextBox txtStreet;
        private MetroFramework.Controls.MetroLabel lblother;
        public MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroButton btnCancel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroLabel suppcode;
        public MetroFramework.Controls.MetroTextBox txtCode;
        public MetroFramework.Controls.MetroTextBox txtContact;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        public MetroFramework.Controls.MetroTextBox txtCity;
        public MetroFramework.Controls.MetroTextBox txtTown;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        public MetroFramework.Controls.MetroTextBox txtNo;
        private MetroFramework.Controls.MetroTile status;
        private System.Windows.Forms.PictureBox icon;
        private System.Windows.Forms.Label title;
        private MaterialSkin.Controls.MaterialDivider materialDivider2;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MaterialSkin.Controls.MaterialDivider materialDivider1;
        private MetroFramework.Controls.MetroLabel metroLabel7;
    }
}