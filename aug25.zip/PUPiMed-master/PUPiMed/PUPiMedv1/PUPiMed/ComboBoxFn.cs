﻿using MetroFramework.Controls;
using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Data;
using System.Windows.Forms;

namespace PUPiMed
{
    class ComboBoxFn
    {
        public bool fillComboBox(MetroComboBox comboBox, string strQuery, out ArrayList alistCode)
        {
            comboBox.Items.Clear();
            alistCode = new ArrayList();
            bool retval = true;
            try
            {
                if (Program.conn != null && (Program.conn.State == ConnectionState.Closed))
                    Program.conn.Open();
                //Create Command
                using (MySqlCommand cmd = new MySqlCommand(strQuery, Program.conn))
                {
                    //Create a data reader and Execute the command
                    using (MySqlDataReader dataReader = cmd.ExecuteReader())
                    {
                        //Read the data and store them in the list
                        if (dataReader.Read())
                        {
                            alistCode.Add(dataReader.GetString(0));
                            comboBox.Items.Add(dataReader.GetString(1));
                            while (dataReader.Read())
                            {
                                alistCode.Add(dataReader.GetString(0));
                                comboBox.Items.Add(dataReader.GetString(1));
                            }
                            //comboBox.Items.Add("Others...");
                            
                        }
                        else
                        {
                            //needs new manufacturer
                            comboBox.Items.Add("");
                            alistCode.Add("");
                            retval = false;
                        }
                        dataReader.Close();
                        comboBox.SelectedIndex = 0;
                    }
                }
                
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally
            {
                //close Connection
                Program.conn.Close();
            }
            return retval;
        }
    }
}
