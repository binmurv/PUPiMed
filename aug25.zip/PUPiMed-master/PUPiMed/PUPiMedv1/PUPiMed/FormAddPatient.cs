﻿using MetroFramework.Forms;
using System;

namespace PUPiMed
{
    public partial class FormAddPatient : MetroForm
    {
        string patientCode;
        string patientType;
        string pLastName;
        string pFirstName;
        string pMiddleName;
        string gender;
        string dob;
        float fltheight;
        float fltweight;
        string contactNo;

        public FormAddPatient()
        {
            InitializeComponent();
            patientype.SelectedIndex = 0;
        }

        private void AddPatient_Load(object sender, EventArgs e)
        {

        }

        private void metroTextBox3_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox4_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void medicon_Click(object sender, EventArgs e)
        {

        }

        private void medname_Click(object sender, EventArgs e)
        {

        }

        private void suppcode_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroLabel9_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel7_Click(object sender, EventArgs e)
        {

        }

        private void lblAddpatient_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
